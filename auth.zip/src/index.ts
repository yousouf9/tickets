import {app} from './app'
import {startDB} from './startup/db'

startDB(app);