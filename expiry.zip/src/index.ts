import {startup} from './startup/db';
startup();