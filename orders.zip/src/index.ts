import {app} from './app'
import {startup} from './startup/db';
startup(app);